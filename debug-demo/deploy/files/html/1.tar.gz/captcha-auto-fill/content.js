console.log("loaded");
// 尝试获取验证码元素和输入框
const captchaImg = document.getElementById('captcha-img');
const codeInput = document.getElementById('code');
const loginButton = document.getElementById('login-submit');
// 设置name和passwd
document.getElementById('name').value = 'test';
document.getElementById('passwd').value = 'test';

if (captchaImg && codeInput && loginButton) {
    // 获取验证码文本内容
    const captchaText = captchaImg.textContent.trim();
    
    // 填写验证码
    codeInput.value = captchaText;
    
    // 模拟点击登录按钮
    setTimeout(() => {
        loginButton.click();
        console.log('验证码已自动填写并提交登录');
    }, 500); // 添加短暂延迟确保值已设置
} else {
    console.log('未找到所需的验证码元素或输入框');
}