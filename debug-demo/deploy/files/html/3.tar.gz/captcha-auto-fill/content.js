console.log("loaded");

document.getElementById("name").value = "admin";
document.getElementById("passwd").value = "1234";

const name1 = document.getElementById('name').value;
const passwd = document.getElementById('passwd').value;

fetch('/login1.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: name1,
    passwd: passwd,
    code: '123'
  })
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    alert('登录成功');
    // 这里可以跳转到其他页面
  } else {
    alert('登录失败: ' + data.message);
  }
})