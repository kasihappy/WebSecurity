console.log("loaded");

document.getElementById("name").value = "admin";
document.getElementById("passwd").value = "1234";

const name1 = document.getElementById('name').value;
const passwd = document.getElementById('passwd').value;
const captchaId = document.getElementById('captcha-id').value;

fetch('/login2.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: name1,
    passwd: passwd,
    code: [1, 2, 3],
    captchaId: captchaId
  })
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    alert('登录成功');
    // 这里可以跳转到其他页面
  } else {
    alert('登录失败: ' + data.message);
  }
})